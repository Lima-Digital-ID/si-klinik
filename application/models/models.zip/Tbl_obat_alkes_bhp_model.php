<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tbl_obat_alkes_bhp_model extends CI_Model
{

    public $table = 'tbl_obat_alkes_bhp';
    public $id = 'kode_barang';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    function get_list()
    {
        $this->db->select('kode_barang, nama_barang');
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
	
	function get_all_alkes($id_klinik = null)
    {
        $this->db->where('jenis_barang', '2'); //Get jenis barang = alat kesehatan
        if($id_klinik != null)
            $this->db->where('id_klinik', $id_klinik);
        
        return $this->db->get($this->table)->result();
    }
	
	function get_all_obat($id_klinik = null)
    {
        // $this->db->where('jenis_barang', '1'); //Get jenis barang = obat
        // if($id_klinik != null)
        //     $this->db->where('id_klinik', $id_klinik);
        
        // return $this->db->get($this->table)->result();
        $query=$this->db->query("SELECT SUM(tid1.jumlah) - COALESCE((SELECT SUM(tid2.jumlah) as jumlah_stok FROM `tbl_inventory_detail` tid2 JOIN tbl_inventory ti2 ON tid2.id_inventory=ti2.id_inventory WHERE ti2.inv_type='TRX_STUFF' AND ti2.id_klinik=MAX(ti.id_klinik) AND tid2.kode_barang=tid1.kode_barang), 0) - COALESCE((SELECT SUM(tid2.jumlah) as jumlah_stok FROM `tbl_inventory_detail` tid2 JOIN tbl_inventory ti2 ON tid2.id_inventory=ti2.id_inventory WHERE ti2.inv_type='RETURN_MONEY' AND ti2.id_klinik=MAX(ti.id_klinik) AND tid2.kode_barang=tid1.kode_barang), 0) as stok_barang, MAX(tid1.kode_barang) AS kode_barang, MAX(tid1.harga) AS harga, MAX(toa.harga) AS harga_jual, MAX(tid1.diskon) AS diskon, MAX(tid1.tgl_exp) AS tgl_exp, MAX(toa.nama_barang) AS nama_barang FROM `tbl_inventory_detail` tid1 JOIN tbl_inventory ti ON tid1.id_inventory=ti.id_inventory JOIN tbl_obat_alkes_bhp toa ON tid1.kode_barang=toa.kode_barang WHERE ti.inv_type='RECEIPT_ORDER' OR ti.inv_type='RETURN_STUFF' AND ti.id_klinik=1 AND toa.jenis_barang=1 GROUP BY tid1.kode_barang");
        return $query->result();
        // SELECT SUM(tid1.jumlah) - COALESCE((SELECT SUM(tid2.jumlah) as jumlah_stok FROM `tbl_inventory_detail` tid2 JOIN tbl_inventory ti2 ON tid2.id_inventory=ti2.id_inventory JOIN tbl_obat_alkes_bhp toa1 ON tid2.kode_barang=toa1.kode_barang WHERE ti2.inv_type='TRX_STUFF' OR ti2.inv_type='RETURN_MONEY' AND ti2.id_klinik=1 AND tid2.kode_barang=tid1.kode_barang), 0) as jumlah_stok, tid1.kode_barang, toa.nama_barang FROM `tbl_inventory_detail` tid1 JOIN tbl_inventory ti ON tid1.id_inventory=ti.id_inventory JOIN tbl_obat_alkes_bhp toa ON tid1.kode_barang=toa.kode_barang WHERE ti.inv_type='RECEIPT_ORDER' OR ti.inv_type='RETURN_STUFF' AND ti.id_klinik=1 AND toa.jenis_barang=1 GROUP BY tid1.kode_barang
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('kode_barang', $q);
	$this->db->or_like('nama_barang', $q);
	$this->db->or_like('id_kategori_barang', $q);
	$this->db->or_like('id_satuan_barang', $q);
	$this->db->or_like('harga', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('tbl_obat_alkes_bhp.kode_barang', $q);
	$this->db->or_like('tbl_obat_alkes_bhp.nama_barang', $q);
	$this->db->or_like('tbl_obat_alkes_bhp.id_kategori_barang', $q);
	$this->db->or_like('tbl_obat_alkes_bhp.id_satuan_barang', $q);
	$this->db->or_like('tbl_obat_alkes_bhp.harga', $q);
        $this->db->join('tbl_kategori_barang','tbl_kategori_barang.id_kategori_barang=tbl_obat_alkes_bhp.id_kategori_barang');
        $this->db->join('tbl_satuan_barang','tbl_satuan_barang.id_satuan=tbl_obat_alkes_bhp.id_satuan_barang');
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }
    
    function json(){
        $this->datatables->select('kode_barang,nama_barang,nama_kategori as kategori_barang,nama_satuan as satuan_barang, barcode ,(CASE jenis_barang WHEN 1 THEN "Obat" WHEN 2 THEN "Alat Kesehatan" ELSE "BHP" END) as jenis_barang,harga,tbl_klinik.nama as klinik');
        $this->datatables->from('tbl_obat_alkes_bhp');
        $this->datatables->join('tbl_kategori_barang', 'tbl_obat_alkes_bhp.id_kategori_barang=tbl_kategori_barang.id_kategori_barang');
        $this->datatables->join('tbl_satuan_barang', 'tbl_obat_alkes_bhp.id_satuan_barang=tbl_satuan_barang.id_satuan');
        $this->datatables->join('tbl_klinik','tbl_obat_alkes_bhp.id_klinik=tbl_klinik.id_klinik');
        $this->datatables->add_column('action', anchor(site_url('dataobat/update/$1'),'<i class="fa fa-pencil-square-o" aria-hidden="true"></i>','class="btn btn-success btn-sm"')." 
                ".anchor(site_url('dataobat/delete/$1'),'<i class="fa fa-trash-o" aria-hidden="true"></i>','class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'kode_barang');
            
        return $this->datatables->generate();
    }

    function get_data_obat($id_klinik = null)
    {
        $this->db->select('tbl_obat_alkes_bhp.*, tbl_pabrik.nama_pabrik');
        $this->db->join('tbl_pabrik','tbl_obat_alkes_bhp.kode_pabrik=tbl_pabrik.kode_pabrik', 'left');
        $this->db->where('tbl_obat_alkes_bhp.jenis_barang', '1'); //Get jenis barang = obat
        if($id_klinik != null)
            $this->db->where('tbl_obat_alkes_bhp.id_klinik', $id_klinik);
        
        return $this->db->get($this->table)->result();
    }
    function get_barang_all()
    {
        $this->db->select('tbl_obat_alkes_bhp.*, tbl_pabrik.nama_pabrik,nama_kategori as kategori_barang,nama_satuan as satuan_barang');
        $this->db->join('tbl_pabrik','tbl_obat_alkes_bhp.kode_pabrik=tbl_pabrik.kode_pabrik', 'left');
        $this->db->join('tbl_kategori_barang', 'tbl_obat_alkes_bhp.id_kategori_barang=tbl_kategori_barang.id_kategori_barang');
        $this->db->join('tbl_satuan_barang', 'tbl_obat_alkes_bhp.id_satuan_barang=tbl_satuan_barang.id_satuan');
        // $this->db->where('tbl_obat_alkes_bhp.jenis_barang', '1'); //Get jenis barang = obat

        return $this->db->get($this->table)->result();
    }

}

/* End of file Tbl_obat_alkes_bhp_model.php */
/* Location: ./application/models/Tbl_obat_alkes_bhp_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-09 11:24:01 */
/* http://harviacode.com */