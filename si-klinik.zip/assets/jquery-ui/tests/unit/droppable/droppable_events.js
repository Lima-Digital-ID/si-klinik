/*
 * droppable_events.js
 */
(function($) {

module("droppable: events");

// this is here to make JSHint pass "unused", and we don't want to
// remove the parameter for when we finally implement
$.noop();

// todo: comment the following in when ready to actually test
/*
test("activate", function() {
	ok(false, 'missing test - untested code is broken code');
});

test("deactivate", function() {
	ok(false, 'missing test - untested code is broken code');
});

test("over", function() {
	ok(false, 'missing test - untested code is broken code');
});

test("out", function() {
	ok(false, 'missing test - untested code is broken code');
});

test("drop", function() {
	ok(false, 'missing test - untested code is broken code');
});
*/

})(jQuery);
